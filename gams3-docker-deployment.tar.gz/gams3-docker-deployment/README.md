# GaMS3 Subtitle Generator - Docker Deployment

Avtomatska transformacija ASR transkriptov v profesionalne podnapise.

## Zahteve

**Hardware:**
- NVIDIA GPU (min 24GB VRAM, priporočeno 80GB A100)
- 32GB+ RAM
- 50GB disk space (za model cache)

**Software:**
- Linux (Ubuntu 20.04+)
- Docker 20.10+
- Docker Compose 2.0+
- NVIDIA Container Toolkit

---

## Setup

### 1. Install Docker & NVIDIA Container Toolkit
```bash
# Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
# Logout in ponovno login

# NVIDIA Container Toolkit
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

# Test GPU
docker run --rm --gpus all nvidia/cuda:12.1.0-base-ubuntu22.04 nvidia-smi
```

### 2. Start Services
```bash
# Build containers (first time only)
docker-compose build

# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Wait for "Application startup complete" (~2-5 min for first run)
```

### 3. Test
```bash
# Health check
curl http://localhost:8001/health

# Transform single text
curl -X POST http://localhost:8001/transform \
  -H "Content-Type: application/json" \
  -d '{"text": "ja torej ta rešitev hmmm ubistvu je to uporabno in dobro"}'